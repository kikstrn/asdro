import {
  type EmailOtpType,
} from "@supabase/supabase-js";

import {
  type NextRequest,
  NextResponse,
} from "next/server";

import {
  createClient,
} from "@/lib/supabase/server";

export async function GET(
  request: NextRequest
) {
  const {
    searchParams,
  } =
    new URL(request.url);

  const tokenHash =
    searchParams.get(
      "token_hash"
    );

  const type =
    searchParams.get(
      "type"
    ) as
      | EmailOtpType
      | null;

  const requestedNext =
    searchParams.get(
      "next"
    );

  const next =
    requestedNext &&
    requestedNext.startsWith(
      "/"
    )
      ? requestedNext
      : type ===
          "recovery"
        ? "/reinitialiser-mot-de-passe"
        : "/";

  const redirectTo =
    request.nextUrl.clone();

  redirectTo.pathname =
    next;

  redirectTo.search = "";

  if (
    tokenHash &&
    type
  ) {
    const supabase =
      await createClient();

    const {
      error,
    } =
      await supabase.auth.verifyOtp(
        {
          type,
          token_hash:
            tokenHash,
        }
      );

    if (!error) {
      return NextResponse.redirect(
        redirectTo
      );
    }

    console.error(
      "Erreur vérification lien Auth :",
      error
    );
  }

  redirectTo.pathname =
    "/connexion";

  redirectTo.searchParams.set(
    "authError",
    "Le lien est invalide ou a expiré."
  );

  return NextResponse.redirect(
    redirectTo
  );
}
